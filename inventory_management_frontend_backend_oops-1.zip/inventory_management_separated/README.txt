INVENTORY MANAGEMENT SYSTEM — SEPARATED PROJECT

Folders:
- frontend/index.html : page structure
- frontend/styles.css : visual design
- frontend/app.js : existing browser-side behavior from your uploaded file
- backend/ : starter Java Spring Boot REST API with OOP-style Product class and MySQL persistence

IMPORTANT:
1. The frontend JavaScript still uses browser localStorage, as in your original file. It has been separated into files, but it is NOT yet wired to the Java API.
2. The Java backend currently provides CRUD endpoints for products. Income, expenditure, and stock movement endpoints still need to be added and connected.
3. This is a starter project, not a complete production system. Test it before presenting/submitting.
4. Requires Java 17+, Maven, and MySQL. Create a database named inventory_db, then update backend/src/main/resources/application.properties with your MySQL password.
5. Run backend from the backend folder: mvn spring-boot:run
6. Product API base URL: http://localhost:8080/api/products
   GET    /api/products       list products
   POST   /api/products       create product (JSON body)
   PUT    /api/products/{id}  update product
   DELETE /api/products/{id}  delete product
7. Open frontend/index.html in a browser to view the UI. Since the UI still uses localStorage, changes there do not automatically go to MySQL until the frontend fetch calls are implemented.

OOP CONCEPTS SHOWN:
- Encapsulation: Product fields are private; getters/setters control access and validate values.
- Abstraction: ProductService offers operations such as add/update/delete without exposing persistence details to the controller.
- Inheritance: ProductRepository extends JpaRepository, inheriting standard database operations.
- Polymorphism: Spring Data provides a repository implementation behind the JpaRepository interface; the controller depends on the repository/service abstractions rather than a concrete implementation.
- Classes and Objects: Product is a class; each product row is an object/entity.
- Constructor: Product constructor initializes product fields.
