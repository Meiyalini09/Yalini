(function(){
  "use strict";

  /* ---------------- Storage ---------------- */
  const LS = {
    products:'ims_products', income:'ims_income', exp:'ims_expenditure',
    movements:'ims_movements', settings:'ims_settings'
  };

  function load(key, fallback){
    try{
      const raw = localStorage.getItem(key);
      if(!raw) return fallback;
      return JSON.parse(raw);
    }catch(e){ return fallback; }
  }
  function save(key, val){
    try{ localStorage.setItem(key, JSON.stringify(val)); }catch(e){ toast('Could not save data locally.', 'err'); }
  }

  const defaultSettings = { shopName:'My Shop', currency:'₹', minStockAlert:5, contact:'+91 00000 00000' };

  let state = {
    products: load(LS.products, null),
    income: load(LS.income, null),
    exp: load(LS.exp, null),
    movements: load(LS.movements, null),
    settings: load(LS.settings, defaultSettings)
  };

  const seeded = state.products === null;
  if(state.products === null){
    state.products = [
      {id:'P001', name:'Laptop', category:'Electronics', description:'15-inch business laptop (sample record)', supplier:'TechSource Pvt Ltd', purchasePrice:38000, sellingPrice:45000, quantity:12, minStock:3},
      {id:'P002', name:'Keyboard', category:'Accessories', description:'Wired mechanical keyboard (sample record)', supplier:'ClickWorks', purchasePrice:900, sellingPrice:1400, quantity:4, minStock:5},
      {id:'P003', name:'Mouse', category:'Accessories', description:'Wireless optical mouse (sample record)', supplier:'ClickWorks', purchasePrice:350, sellingPrice:600, quantity:0, minStock:5},
      {id:'P004', name:'Printer', category:'Electronics', description:'All-in-one inkjet printer (sample record)', supplier:'TechSource Pvt Ltd', purchasePrice:7000, sellingPrice:9500, quantity:6, minStock:2}
    ];
  }
  if(state.income === null){
    state.income = [
      {id:'IN-1001', date: daysAgo(4), description:'Sale of 2 laptops', productId:'P001', quantity:2, amount:90000, paymentMethod:'Bank Transfer', notes:''},
      {id:'IN-1002', date: daysAgo(1), description:'Sale of printer', productId:'P004', quantity:1, amount:9500, paymentMethod:'UPI', notes:''}
    ];
  }
  if(state.exp === null){
    state.exp = [
      {id:'EX-2001', date: daysAgo(6), description:'Shop electricity bill', category:'Electricity', amount:2200, paymentMethod:'Cash', notes:''},
      {id:'EX-2002', date: daysAgo(2), description:'Restocking keyboards', category:'Product Purchase', amount:9000, paymentMethod:'Bank Transfer', notes:''}
    ];
  }
  if(state.movements === null){
    state.movements = [
      {id:'M-1', date: daysAgo(6), productId:'P001', type:'Added', quantity:15, reason:'Initial stock'},
      {id:'M-2', date: daysAgo(4), productId:'P001', type:'Removed', quantity:2, reason:'Sale'},
      {id:'M-3', date: daysAgo(2), productId:'P003', type:'Removed', quantity:6, reason:'Sale'}
    ];
  }
  persistAll();

  function daysAgo(n){
    const d = new Date(); d.setDate(d.getDate()-n);
    return d.toISOString().slice(0,10);
  }
  function today(){ return new Date().toISOString().slice(0,10); }

  function persistAll(){
    save(LS.products, state.products);
    save(LS.income, state.income);
    save(LS.exp, state.exp);
    save(LS.movements, state.movements);
    save(LS.settings, state.settings);
  }

  /* ---------------- Helpers ---------------- */
  function fmtMoney(n){
    n = Number(n)||0;
    return state.settings.currency + ' ' + n.toLocaleString('en-IN', {maximumFractionDigits:2});
  }
  function computeStatus(p){
    const q = Number(p.quantity)||0, m = Number(p.minStock)||0;
    if(q === 0) return 'Out of Stock';
    if(q <= m) return 'Low Stock';
    return 'Available';
  }
  function statusBadgeClass(s){
    if(s==='Available') return 'available';
    if(s==='Low Stock') return 'low';
    return 'out';
  }
  function esc(s){
    return String(s===undefined||s===null?'':s).replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }
  function uid(prefix){
    return prefix + '-' + Date.now().toString(36).slice(-5) + Math.floor(Math.random()*90+10);
  }

  function toast(msg, type){
    const wrap = document.getElementById('toast-wrap');
    const el = document.createElement('div');
    el.className = 'toast' + (type==='err'?' err':type==='ok'?' ok':'');
    const icon = type==='err'
      ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 8v5M12 16h.01"/></svg>'
      : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 6L9 17l-5-5"/></svg>';
    el.innerHTML = icon + '<span>'+esc(msg)+'</span>';
    wrap.appendChild(el);
    setTimeout(()=>{ el.style.opacity='0'; el.style.transition='opacity .3s'; setTimeout(()=>el.remove(), 300); }, 2600);
  }

  function openModal(id){ document.getElementById(id).classList.add('show'); }
  window.closeModal = function(id){ document.getElementById(id).classList.remove('show'); };

  function clearErrors(formEl){
    formEl.querySelectorAll('.field').forEach(f=>f.classList.remove('invalid'));
  }
  function markInvalid(fieldEl){ fieldEl.closest('.field').classList.add('invalid'); }

  /* ---------------- Navigation ---------------- */
  const views = ['dashboard','products','stock','income','expenditure','transactions','reports','settings'];
  const titles = {dashboard:'Dashboard', products:'Products', stock:'Stock Movement', income:'Income', expenditure:'Expenditure', transactions:'Transactions', reports:'Reports', settings:'Settings'};
  const crumbs = {dashboard:'overview / today', products:'inventory / products', stock:'inventory / stock', income:'finance / income', expenditure:'finance / expenditure', transactions:'finance / all', reports:'finance / reports', settings:'shop / settings'};

  function goTo(view){
    views.forEach(v=>{
      document.getElementById('view-'+v).classList.toggle('active', v===view);
    });
    document.querySelectorAll('.navlink').forEach(l=>l.classList.toggle('active', l.dataset.view===view));
    document.getElementById('pageTitle').textContent = titles[view];
    document.getElementById('pageCrumb').textContent = crumbs[view];
    document.getElementById('sidebar').classList.remove('open');
    renderAll();
    window.scrollTo(0,0);
  }
  document.querySelectorAll('.navlink').forEach(l=>l.addEventListener('click', ()=>goTo(l.dataset.view)));
  document.getElementById('menuBtn').addEventListener('click', ()=>document.getElementById('sidebar').classList.toggle('open'));

  /* ---------------- Theme ---------------- */
  const root = document.documentElement;
  let theme = localStorage.getItem('ims_theme');
  if(theme) root.setAttribute('data-theme', theme);
  function paintThemeIcon(){
    const isDark = getComputedStyle(root).getPropertyValue('--paper').trim().startsWith('#15') || root.getAttribute('data-theme')==='dark';
  }
  document.getElementById('themeToggle').addEventListener('click', ()=>{
    const current = root.getAttribute('data-theme') || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark':'light');
    const next = current==='dark' ? 'light' : 'dark';
    root.setAttribute('data-theme', next);
    try{ localStorage.setItem('ims_theme', next); }catch(e){}
  });

  /* ---------------- Dashboard ---------------- */
  function renderDashboard(){
    const totalProducts = state.products.length;
    const totalQty = state.products.reduce((s,p)=>s+Number(p.quantity||0),0);
    const invValue = state.products.reduce((s,p)=>s+Number(p.quantity||0)*Number(p.purchasePrice||0),0);
    const totalIncome = state.income.reduce((s,t)=>s+Number(t.amount||0),0);
    const totalExp = state.exp.reduce((s,t)=>s+Number(t.amount||0),0);
    const profit = totalIncome - totalExp;
    const lowStock = state.products.filter(p=>computeStatus(p)==='Low Stock');
    const outStock = state.products.filter(p=>computeStatus(p)==='Out of Stock');

    const cards = [
      {label:'Total Products', value: totalProducts},
      {label:'Total Stock Quantity', value: totalQty},
      {label:'Total Inventory Value', value: fmtMoney(invValue)},
      {label:'Total Income', value: fmtMoney(totalIncome), cls:'good'},
      {label:'Total Expenditure', value: fmtMoney(totalExp), cls:'danger'},
      {label:'Net Profit', value: fmtMoney(profit), cls: profit>=0?'good':'danger'},
      {label:'Low Stock Products', value: lowStock.length, cls:'warn'},
      {label:'Out of Stock Products', value: outStock.length, cls:'danger'}
    ];
    document.getElementById('dashCards').innerHTML = cards.map(c=>`
      <div class="card ${c.cls||''}"><div class="label">${esc(c.label)}</div><div class="value">${c.value}</div></div>
    `).join('');

    // low stock list
    const lowList = [...lowStock, ...outStock].slice(0,6);
    document.getElementById('dashLowStock').innerHTML = lowList.length ? lowList.map(p=>`
      <li><div><div class="mtitle">${esc(p.name)}</div><div class="msub">${esc(p.id)} · Qty ${p.quantity}</div></div><span class="badge ${statusBadgeClass(computeStatus(p))}"><span class="dot"></span>${computeStatus(p)}</span></li>
    `).join('') : emptyRowHTML('All products are sufficiently stocked.');

    // recent transactions
    const allTx = [
      ...state.income.map(t=>({...t, type:'Income'})),
      ...state.exp.map(t=>({...t, type:'Expenditure'}))
    ].sort((a,b)=> (b.date||'').localeCompare(a.date||'')).slice(0,6);
    document.getElementById('dashRecentTx').innerHTML = allTx.length ? allTx.map(t=>`
      <li><div><div class="mtitle">${esc(t.description)}</div><div class="msub">${esc(t.date)} · ${esc(t.paymentMethod)}</div></div><span class="badge ${t.type.toLowerCase()}">${t.type==='Income'?'+':'-'} ${fmtMoney(t.amount)}</span></li>
    `).join('') : emptyRowHTML('No transactions recorded yet.');

    // recent products
    const recentProducts = [...state.products].slice(-5).reverse();
    document.getElementById('dashRecentProducts').innerHTML = recentProducts.length ? recentProducts.map(p=>`
      <li><div><div class="mtitle">${esc(p.name)}</div><div class="msub">${esc(p.id)} · ${esc(p.category)}</div></div><span class="badge ${statusBadgeClass(computeStatus(p))}"><span class="dot"></span>${computeStatus(p)}</span></li>
    `).join('') : emptyRowHTML('No products yet.');

    drawIEChart();
  }

  function emptyRowHTML(msg){
    return `<li style="justify-content:center;color:var(--text-dim);font-size:12.5px;">${esc(msg)}</li>`;
  }

  function drawIEChart(){
    const svg = document.getElementById('ieChart');
    // build last up-to-6 combined by date bucket (grouped by date string)
    const map = {};
    state.income.forEach(t=>{ map[t.date] = map[t.date]||{inc:0,exp:0}; map[t.date].inc += Number(t.amount||0); });
    state.exp.forEach(t=>{ map[t.date] = map[t.date]||{inc:0,exp:0}; map[t.date].exp += Number(t.amount||0); });
    let entries = Object.keys(map).sort().map(d=>({date:d, ...map[d]}));
    entries = entries.slice(-6);
    if(entries.length===0){
      svg.innerHTML = `<text x="280" y="110" text-anchor="middle" fill="var(--text-dim)" font-size="13">No income or expenditure data yet.</text>`;
      return;
    }
    const W=560,H=220,padL=44,padB=28,padT=16,padR=10;
    const maxVal = Math.max(1, ...entries.map(e=>Math.max(e.inc,e.exp)));
    const chartW = W-padL-padR, chartH = H-padT-padB;
    const groupW = chartW/entries.length;
    const barW = Math.min(22, groupW/3);
    let bars = '', labels='', gridlines='';
    for(let g=0; g<=4; g++){
      const y = padT + chartH - (g/4)*chartH;
      gridlines += `<line x1="${padL}" y1="${y}" x2="${W-padR}" y2="${y}" stroke="var(--line)" stroke-width="1"/>`;
      gridlines += `<text x="${padL-8}" y="${y+4}" text-anchor="end" font-size="9.5" fill="var(--text-dim)" font-family="IBM Plex Mono, monospace">${Math.round(maxVal*g/4)}</text>`;
    }
    entries.forEach((e,i)=>{
      const cx = padL + i*groupW + groupW/2;
      const hInc = (e.inc/maxVal)*chartH;
      const hExp = (e.exp/maxVal)*chartH;
      bars += `<rect x="${cx-barW-2}" y="${padT+chartH-hInc}" width="${barW}" height="${hInc}" fill="var(--teal)" rx="1.5"/>`;
      bars += `<rect x="${cx+2}" y="${padT+chartH-hExp}" width="${barW}" height="${hExp}" fill="var(--rust)" rx="1.5"/>`;
      const short = e.date.slice(5);
      labels += `<text x="${cx}" y="${H-8}" text-anchor="middle" font-size="10" fill="var(--text-dim)" font-family="IBM Plex Mono, monospace">${short}</text>`;
    });
    svg.innerHTML = gridlines + bars + labels +
      `<rect x="${W-150}" y="4" width="9" height="9" fill="var(--teal)"/><text x="${W-137}" y="12" font-size="10" fill="var(--text-dim)">Income</text>` +
      `<rect x="${W-70}" y="4" width="9" height="9" fill="var(--rust)"/><text x="${W-57}" y="12" font-size="10" fill="var(--text-dim)">Expenditure</text>`;
  }

  /* ---------------- Products ---------------- */
  let productFilter = 'all', productQuery = '';

  function filteredProducts(){
    return state.products.filter(p=>{
      const status = computeStatus(p);
      if(productFilter!=='all' && status!==productFilter) return false;
      if(!productQuery) return true;
      const q = productQuery.toLowerCase();
      return [p.id,p.name,p.category,p.supplier].some(f=>String(f||'').toLowerCase().includes(q));
    });
  }

  function renderProducts(){
    const list = filteredProducts();
    const wrap = document.getElementById('productsTableWrap');
    if(list.length===0){
      wrap.innerHTML = emptyState('No products found', productQuery ? 'Try a different search term or filter.' : 'Click "Add Product" to create your first product.');
      return;
    }
    wrap.innerHTML = `<table><thead><tr>
      <th>Product ID</th><th>Name</th><th>Category</th><th>Supplier</th><th>Purchase ₹</th><th>Selling ₹</th><th>Qty</th><th>Status</th><th>Actions</th>
    </tr></thead><tbody>
      ${list.map(p=>{
        const status = computeStatus(p);
        return `<tr>
          <td class="num">${esc(p.id)}</td>
          <td>${esc(p.name)}</td>
          <td>${esc(p.category)}</td>
          <td>${esc(p.supplier)}</td>
          <td class="num">${Number(p.purchasePrice).toLocaleString('en-IN')}</td>
          <td class="num">${Number(p.sellingPrice).toLocaleString('en-IN')}</td>
          <td class="num">${p.quantity}</td>
          <td><span class="badge ${statusBadgeClass(status)}"><span class="dot"></span>${status}</span></td>
          <td><div class="row-actions">
            <button class="icon-btn" title="View" onclick="IMS.viewProduct('${esc(p.id)}')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7z"/><circle cx="12" cy="12" r="3"/></svg></button>
            <button class="icon-btn" title="Edit" onclick="IMS.editProduct('${esc(p.id)}')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z"/></svg></button>
            <button class="icon-btn del" title="Delete" onclick="IMS.deleteProduct('${esc(p.id)}')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0-1 14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2L4 6"/></svg></button>
          </div></td>
        </tr>`;
      }).join('')}
    </tbody></table>`;
  }

  function emptyState(title, sub){
    return `<div class="empty-state">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21 8l-9-5-9 5 9 5 9-5z"/><path d="M3 8v8l9 5 9-5V8"/></svg>
      <div class="em-title">${esc(title)}</div><div class="em-sub">${esc(sub)}</div>
    </div>`;
  }

  document.getElementById('productSearch').addEventListener('input', e=>{ productQuery = e.target.value; renderProducts(); });
  document.querySelectorAll('#view-products .filter-chip').forEach(chip=>{
    chip.addEventListener('click', ()=>{
      document.querySelectorAll('#view-products .filter-chip').forEach(c=>c.classList.remove('active'));
      chip.classList.add('active');
      productFilter = chip.dataset.status;
      renderProducts();
    });
  });

  let editingProductId = null;
  document.getElementById('addProductBtn').addEventListener('click', ()=>{
    editingProductId = null;
    document.getElementById('productModalTitle').textContent = 'Add Product';
    document.getElementById('productForm').reset();
    document.getElementById('pf_id').disabled = false;
    document.getElementById('pf_status').value = 'Available';
    clearErrors(document.getElementById('productForm'));
    openModal('productModalOverlay');
  });

  function fillProductForm(p){
    document.getElementById('pf_id').value = p.id;
    document.getElementById('pf_id').disabled = true;
    document.getElementById('pf_name').value = p.name;
    document.getElementById('pf_category').value = p.category;
    document.getElementById('pf_supplier').value = p.supplier;
    document.getElementById('pf_description').value = p.description||'';
    document.getElementById('pf_purchasePrice').value = p.purchasePrice;
    document.getElementById('pf_sellingPrice').value = p.sellingPrice;
    document.getElementById('pf_quantity').value = p.quantity;
    document.getElementById('pf_minStock').value = p.minStock;
    document.getElementById('pf_status').value = computeStatus(p);
  }

  window.IMS = window.IMS || {};
  IMS.editProduct = function(id){
    const p = state.products.find(x=>x.id===id);
    if(!p) return;
    editingProductId = id;
    document.getElementById('productModalTitle').textContent = 'Edit Product';
    clearErrors(document.getElementById('productForm'));
    fillProductForm(p);
    openModal('productModalOverlay');
  };
  IMS.viewProduct = function(id){
    const p = state.products.find(x=>x.id===id);
    if(!p) return;
    const status = computeStatus(p);
    const rows = [
      ['Product ID', p.id], ['Product Name', p.name], ['Category', p.category], ['Description', p.description||'—'],
      ['Supplier', p.supplier], ['Purchase Price', fmtMoney(p.purchasePrice)], ['Selling Price', fmtMoney(p.sellingPrice)],
      ['Current Quantity', p.quantity], ['Minimum Stock Level', p.minStock], ['Stock Status', status],
      ['Total Stock Value', fmtMoney(Number(p.purchasePrice)*Number(p.quantity))]
    ];
    document.getElementById('viewProductBody').innerHTML = rows.map(r=>`<li><span class="msub">${esc(r[0])}</span><span class="mtitle">${esc(r[1])}</span></li>`).join('');
    openModal('viewProductOverlay');
  };
  IMS.deleteProduct = function(id){
    const p = state.products.find(x=>x.id===id);
    if(!p) return;
    showConfirm(`Are you sure you want to delete "${p.name}" (${p.id})? This cannot be undone.`, ()=>{
      state.products = state.products.filter(x=>x.id!==id);
      persistAll();
      toast('Product deleted successfully!', 'ok');
      renderAll();
    });
  };

  document.getElementById('saveProductBtn').addEventListener('click', ()=>{
    const form = document.getElementById('productForm');
    clearErrors(form);
    const id = document.getElementById('pf_id').value.trim();
    const name = document.getElementById('pf_name').value.trim();
    const category = document.getElementById('pf_category').value.trim();
    const supplier = document.getElementById('pf_supplier').value.trim();
    const description = document.getElementById('pf_description').value.trim();
    const purchasePrice = parseFloat(document.getElementById('pf_purchasePrice').value);
    const sellingPrice = parseFloat(document.getElementById('pf_sellingPrice').value);
    const quantity = parseInt(document.getElementById('pf_quantity').value, 10);
    const minStock = parseInt(document.getElementById('pf_minStock').value, 10);

    let ok = true;
    if(!id){ markInvalid(document.getElementById('pf_id')); ok=false; }
    else if(!editingProductId && state.products.some(p=>p.id===id)){ markInvalid(document.getElementById('pf_id')); document.getElementById('pf_id').closest('.field').querySelector('.err').textContent='This Product ID already exists.'; ok=false; }
    if(!name){ markInvalid(document.getElementById('pf_name')); ok=false; }
    if(!category){ markInvalid(document.getElementById('pf_category')); ok=false; }
    if(!supplier){ markInvalid(document.getElementById('pf_supplier')); ok=false; }
    if(isNaN(purchasePrice) || purchasePrice<0){ markInvalid(document.getElementById('pf_purchasePrice')); ok=false; }
    if(isNaN(sellingPrice) || sellingPrice<0){ markInvalid(document.getElementById('pf_sellingPrice')); ok=false; }
    if(isNaN(quantity) || quantity<0){ markInvalid(document.getElementById('pf_quantity')); ok=false; }
    if(isNaN(minStock) || minStock<0){ markInvalid(document.getElementById('pf_minStock')); ok=false; }

    if(!ok){ toast('Please fix the highlighted fields.', 'err'); return; }

    const productObj = {id, name, category, description, supplier, purchasePrice, sellingPrice, quantity, minStock};

    if(editingProductId){
      const idx = state.products.findIndex(p=>p.id===editingProductId);
      state.products[idx] = productObj;
      toast('Product updated successfully!', 'ok');
    } else {
      state.products.push(productObj);
      toast('Product added successfully!', 'ok');
    }
    persistAll();
    closeModal('productModalOverlay');
    renderAll();
  });

  /* ---------------- Stock Movement ---------------- */
  function renderStock(){
    const totalQty = state.products.reduce((s,p)=>s+Number(p.quantity||0),0);
    const lowCount = state.products.filter(p=>computeStatus(p)==='Low Stock').length;
    const outCount = state.products.filter(p=>computeStatus(p)==='Out of Stock').length;
    document.getElementById('stockCards').innerHTML = `
      <div class="card"><div class="label">Total Stock Quantity</div><div class="value">${totalQty}</div></div>
      <div class="card warn"><div class="label">Low Stock</div><div class="value">${lowCount}</div></div>
    `;

    const watch = state.products.filter(p=>computeStatus(p)!=='Available');
    const lowWrap = document.getElementById('lowStockTableWrap');
    lowWrap.innerHTML = watch.length ? `<table><thead><tr><th>Product</th><th>Current Qty</th><th>Min Stock</th><th>Status</th></tr></thead><tbody>
      ${watch.map(p=>`<tr><td>${esc(p.name)} <span class="msub num">${esc(p.id)}</span></td><td class="num">${p.quantity}</td><td class="num">${p.minStock}</td><td><span class="badge ${statusBadgeClass(computeStatus(p))}"><span class="dot"></span>${computeStatus(p)}</span></td></tr>`).join('')}
    </tbody></table>` : emptyState('No stock warnings', 'All products are above their minimum stock level.');

    const moves = [...state.movements].sort((a,b)=>b.date.localeCompare(a.date));
    const mWrap = document.getElementById('movementTableWrap');
    mWrap.innerHTML = moves.length ? `<table><thead><tr><th>Date</th><th>Product</th><th>Type</th><th>Qty</th><th>Reason</th></tr></thead><tbody>
      ${moves.map(m=>{
        const p = state.products.find(x=>x.id===m.productId);
        return `<tr><td class="num">${esc(m.date)}</td><td>${esc(p?p.name:m.productId)}</td><td><span class="badge ${m.type==='Added'?'income':'expenditure'}">${esc(m.type)}</span></td><td class="num">${m.quantity}</td><td>${esc(m.reason||'—')}</td></tr>`;
      }).join('')}
    </tbody></table>` : emptyState('No stock movements yet', 'Record a movement to track additions and removals.');

    // populate product select
    const sel = document.getElementById('mf_product');
    sel.innerHTML = state.products.map(p=>`<option value="${esc(p.id)}">${esc(p.name)} (${esc(p.id)})</option>`).join('') || '<option value="">No products available</option>';
  }

  document.getElementById('addMovementBtn').addEventListener('click', ()=>{
    if(state.products.length===0){ toast('Add a product first.', 'err'); return; }
    document.getElementById('movementForm').reset();
    clearErrors(document.getElementById('movementForm'));
    document.getElementById('mf_date').value = today();
    renderStock();
    openModal('movementModalOverlay');
  });

  document.getElementById('saveMovementBtn').addEventListener('click', ()=>{
    const form = document.getElementById('movementForm');
    clearErrors(form);
    const productId = document.getElementById('mf_product').value;
    const type = document.getElementById('mf_type').value;
    const quantity = parseInt(document.getElementById('mf_quantity').value, 10);
    const date = document.getElementById('mf_date').value || today();
    const reason = document.getElementById('mf_reason').value.trim();

    let ok = true;
    if(!productId){ markInvalid(document.getElementById('mf_product')); ok=false; }
    if(isNaN(quantity) || quantity<1){ markInvalid(document.getElementById('mf_quantity')); ok=false; }
    if(!ok){ toast('Please fix the highlighted fields.', 'err'); return; }

    const p = state.products.find(x=>x.id===productId);
    if(type==='Removed' && quantity > Number(p.quantity)){
      toast('Cannot remove more stock than is currently available.', 'err');
      markInvalid(document.getElementById('mf_quantity'));
      return;
    }
    p.quantity = Number(p.quantity) + (type==='Added' ? quantity : -quantity);
    state.movements.push({id: uid('M'), date, productId, type, quantity, reason});
    persistAll();
    toast('Stock movement recorded!', 'ok');
    closeModal('movementModalOverlay');
    renderAll();
  });

  /* ---------------- Income ---------------- */
  let incomeQuery = '';
  function renderIncome(){
    const sel = document.getElementById('if_product');
    sel.innerHTML = '<option value="">— none —</option>' + state.products.map(p=>`<option value="${esc(p.id)}">${esc(p.name)} (${esc(p.id)})</option>`).join('');

    const list = state.income.filter(t=>{
      if(!incomeQuery) return true;
      const q = incomeQuery.toLowerCase();
      return [t.id,t.description,t.paymentMethod].some(f=>String(f||'').toLowerCase().includes(q));
    }).sort((a,b)=>b.date.localeCompare(a.date));

    const wrap = document.getElementById('incomeTableWrap');
    wrap.innerHTML = list.length ? `<table><thead><tr><th>Txn ID</th><th>Date</th><th>Description</th><th>Product</th><th>Qty</th><th>Amount</th><th>Payment</th><th>Actions</th></tr></thead><tbody>
      ${list.map(t=>{
        const p = state.products.find(x=>x.id===t.productId);
        return `<tr>
          <td class="num">${esc(t.id)}</td><td class="num">${esc(t.date)}</td><td>${esc(t.description)}</td>
          <td>${p?esc(p.name):'—'}</td><td class="num">${t.quantity||0}</td><td class="num">${fmtMoney(t.amount)}</td><td>${esc(t.paymentMethod)}</td>
          <td><div class="row-actions">
            <button class="icon-btn" title="Edit" onclick="IMS.editIncome('${esc(t.id)}')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z"/></svg></button>
            <button class="icon-btn del" title="Delete" onclick="IMS.deleteIncome('${esc(t.id)}')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0-1 14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2L4 6"/></svg></button>
          </div></td>
        </tr>`;
      }).join('')}
    </tbody></table>` : emptyState('No income recorded', 'Click "Add Income" to record your first transaction.');
  }
  document.getElementById('incomeSearch').addEventListener('input', e=>{ incomeQuery = e.target.value; renderIncome(); });

  let editingIncomeId = null;
  document.getElementById('addIncomeBtn').addEventListener('click', ()=>{
    editingIncomeId = null;
    document.getElementById('incomeModalTitle').textContent = 'Add Income';
    document.getElementById('incomeForm').reset();
    clearErrors(document.getElementById('incomeForm'));
    document.getElementById('if_id').value = uid('IN');
    document.getElementById('if_date').value = today();
    renderIncome();
    openModal('incomeModalOverlay');
  });
  IMS.editIncome = function(id){
    const t = state.income.find(x=>x.id===id);
    if(!t) return;
    editingIncomeId = id;
    document.getElementById('incomeModalTitle').textContent = 'Edit Income';
    clearErrors(document.getElementById('incomeForm'));
    renderIncome();
    document.getElementById('if_id').value = t.id;
    document.getElementById('if_date').value = t.date;
    document.getElementById('if_description').value = t.description;
    document.getElementById('if_product').value = t.productId||'';
    document.getElementById('if_quantity').value = t.quantity||0;
    document.getElementById('if_amount').value = t.amount;
    document.getElementById('if_payment').value = t.paymentMethod;
    document.getElementById('if_notes').value = t.notes||'';
    openModal('incomeModalOverlay');
  };
  IMS.deleteIncome = function(id){
    const t = state.income.find(x=>x.id===id);
    showConfirm(`Delete income transaction "${t.description}"?`, ()=>{
      state.income = state.income.filter(x=>x.id!==id);
      persistAll(); toast('Income transaction deleted.', 'ok'); renderAll();
    });
  };
  document.getElementById('saveIncomeBtn').addEventListener('click', ()=>{
    const form = document.getElementById('incomeForm');
    clearErrors(form);
    const date = document.getElementById('if_date').value;
    const description = document.getElementById('if_description').value.trim();
    const productId = document.getElementById('if_product').value;
    const quantity = parseInt(document.getElementById('if_quantity').value,10) || 0;
    const amount = parseFloat(document.getElementById('if_amount').value);
    const paymentMethod = document.getElementById('if_payment').value;
    const notes = document.getElementById('if_notes').value.trim();

    let ok = true;
    if(!date){ markInvalid(document.getElementById('if_date')); ok=false; }
    if(!description){ markInvalid(document.getElementById('if_description')); ok=false; }
    if(isNaN(amount) || amount<=0){ markInvalid(document.getElementById('if_amount')); ok=false; }
    if(!ok){ toast('Please fix the highlighted fields.', 'err'); return; }

    if(editingIncomeId){
      const idx = state.income.findIndex(t=>t.id===editingIncomeId);
      state.income[idx] = {...state.income[idx], date, description, productId, quantity, amount, paymentMethod, notes};
      toast('Income transaction updated!', 'ok');
    } else {
      state.income.push({id: document.getElementById('if_id').value, date, description, productId, quantity, amount, paymentMethod, notes});
      toast('Income added successfully!', 'ok');
    }
    persistAll();
    closeModal('incomeModalOverlay');
    renderAll();
  });

  /* ---------------- Expenditure ---------------- */
  let expQuery = '';
  function renderExp(){
    const list = state.exp.filter(t=>{
      if(!expQuery) return true;
      const q = expQuery.toLowerCase();
      return [t.id,t.description,t.category,t.paymentMethod].some(f=>String(f||'').toLowerCase().includes(q));
    }).sort((a,b)=>b.date.localeCompare(a.date));

    const wrap = document.getElementById('expTableWrap');
    wrap.innerHTML = list.length ? `<table><thead><tr><th>Txn ID</th><th>Date</th><th>Description</th><th>Category</th><th>Amount</th><th>Payment</th><th>Actions</th></tr></thead><tbody>
      ${list.map(t=>`<tr>
        <td class="num">${esc(t.id)}</td><td class="num">${esc(t.date)}</td><td>${esc(t.description)}</td><td>${esc(t.category)}</td>
        <td class="num">${fmtMoney(t.amount)}</td><td>${esc(t.paymentMethod)}</td>
        <td><div class="row-actions">
          <button class="icon-btn" title="Edit" onclick="IMS.editExp('${esc(t.id)}')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z"/></svg></button>
          <button class="icon-btn del" title="Delete" onclick="IMS.deleteExp('${esc(t.id)}')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0-1 14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2L4 6"/></svg></button>
        </div></td>
      </tr>`).join('')}
    </tbody></table>` : emptyState('No expenditure recorded', 'Click "Add Expenditure" to record your first expense.');
  }
  document.getElementById('expSearch').addEventListener('input', e=>{ expQuery = e.target.value; renderExp(); });

  let editingExpId = null;
  document.getElementById('addExpBtn').addEventListener('click', ()=>{
    editingExpId = null;
    document.getElementById('expModalTitle').textContent = 'Add Expenditure';
    document.getElementById('expForm').reset();
    clearErrors(document.getElementById('expForm'));
    document.getElementById('ef_id').value = uid('EX');
    document.getElementById('ef_date').value = today();
    openModal('expModalOverlay');
  });
  IMS.editExp = function(id){
    const t = state.exp.find(x=>x.id===id);
    if(!t) return;
    editingExpId = id;
    document.getElementById('expModalTitle').textContent = 'Edit Expenditure';
    clearErrors(document.getElementById('expForm'));
    document.getElementById('ef_id').value = t.id;
    document.getElementById('ef_date').value = t.date;
    document.getElementById('ef_description').value = t.description;
    document.getElementById('ef_category').value = t.category;
    document.getElementById('ef_amount').value = t.amount;
    document.getElementById('ef_payment').value = t.paymentMethod;
    document.getElementById('ef_notes').value = t.notes||'';
    openModal('expModalOverlay');
  };
  IMS.deleteExp = function(id){
    const t = state.exp.find(x=>x.id===id);
    showConfirm(`Delete expenditure "${t.description}"?`, ()=>{
      state.exp = state.exp.filter(x=>x.id!==id);
      persistAll(); toast('Expenditure deleted.', 'ok'); renderAll();
    });
  };
  document.getElementById('saveExpBtn').addEventListener('click', ()=>{
    clearErrors(document.getElementById('expForm'));
    const date = document.getElementById('ef_date').value;
    const description = document.getElementById('ef_description').value.trim();
    const category = document.getElementById('ef_category').value;
    const amount = parseFloat(document.getElementById('ef_amount').value);
    const paymentMethod = document.getElementById('ef_payment').value;
    const notes = document.getElementById('ef_notes').value.trim();

    let ok = true;
    if(!date){ markInvalid(document.getElementById('ef_date')); ok=false; }
    if(!description){ markInvalid(document.getElementById('ef_description')); ok=false; }
    if(isNaN(amount) || amount<=0){ markInvalid(document.getElementById('ef_amount')); ok=false; }
    if(!ok){ toast('Please fix the highlighted fields.', 'err'); return; }

    if(editingExpId){
      const idx = state.exp.findIndex(t=>t.id===editingExpId);
      state.exp[idx] = {...state.exp[idx], date, description, category, amount, paymentMethod, notes};
      toast('Expenditure updated!', 'ok');
    } else {
      state.exp.push({id: document.getElementById('ef_id').value, date, description, category, amount, paymentMethod, notes});
      toast('Expenditure added successfully!', 'ok');
    }
    persistAll();
    closeModal('expModalOverlay');
    renderAll();
  });

  /* ---------------- Transactions ---------------- */
  let txTypeFilter = 'all', txDateFilter = '';
  document.querySelectorAll('#view-transactions .filter-chip').forEach(chip=>{
    chip.addEventListener('click', ()=>{
      document.querySelectorAll('#view-transactions .filter-chip').forEach(c=>c.classList.remove('active'));
      chip.classList.add('active');
      txTypeFilter = chip.dataset.tx;
      renderTransactions();
    });
  });
  document.getElementById('txDateFilter').addEventListener('change', e=>{ txDateFilter = e.target.value; renderTransactions(); });

  function renderTransactions(){
    let all = [
      ...state.income.map(t=>({...t, type:'Income'})),
      ...state.exp.map(t=>({...t, type:'Expenditure'}))
    ];
    if(txTypeFilter!=='all') all = all.filter(t=>t.type===txTypeFilter);
    if(txDateFilter) all = all.filter(t=>t.date===txDateFilter);
    all.sort((a,b)=>b.date.localeCompare(a.date));

    const wrap = document.getElementById('txTableWrap');
    wrap.innerHTML = all.length ? `<table><thead><tr><th>Date</th><th>Type</th><th>Description</th><th>Amount</th><th>Payment Method</th></tr></thead><tbody>
      ${all.map(t=>`<tr><td class="num">${esc(t.date)}</td><td><span class="badge ${t.type.toLowerCase()}">${esc(t.type)}</span></td><td>${esc(t.description)}</td><td class="num">${t.type==='Income'?'+':'-'} ${fmtMoney(t.amount)}</td><td>${esc(t.paymentMethod)}</td></tr>`).join('')}
    </tbody></table>` : emptyState('No transactions found', 'Try a different filter.');
  }

  /* ---------------- Reports ---------------- */
  function renderReports(){
    const totalProducts = state.products.length;
    const totalQty = state.products.reduce((s,p)=>s+Number(p.quantity||0),0);
    const invValue = state.products.reduce((s,p)=>s+Number(p.quantity||0)*Number(p.purchasePrice||0),0);
    const lowCount = state.products.filter(p=>computeStatus(p)==='Low Stock').length;
    const outCount = state.products.filter(p=>computeStatus(p)==='Out of Stock').length;
    document.getElementById('repInventory').innerHTML = [
      ['Total Products', totalProducts],['Total Quantity', totalQty],['Inventory Value', fmtMoney(invValue)],
      ['Low Stock Count', lowCount],['Out of Stock Count', outCount]
    ].map(r=>`<li><span class="msub">${r[0]}</span><span class="mtitle">${r[1]}</span></li>`).join('');

    const totalIncome = state.income.reduce((s,t)=>s+Number(t.amount||0),0);
    const totalExp = state.exp.reduce((s,t)=>s+Number(t.amount||0),0);
    document.getElementById('repIncome').innerHTML = `<li><span class="msub">Total Income</span><span class="mtitle">${fmtMoney(totalIncome)}</span></li>` +
      (state.income.length ? state.income.slice(-5).reverse().map(t=>`<li><span class="msub">${esc(t.date)} · ${esc(t.description)}</span><span class="mtitle">${fmtMoney(t.amount)}</span></li>`).join('') : emptyRowHTML('No income transactions yet.'));
    document.getElementById('repExp').innerHTML = `<li><span class="msub">Total Expenditure</span><span class="mtitle">${fmtMoney(totalExp)}</span></li>` +
      (state.exp.length ? state.exp.slice(-5).reverse().map(t=>`<li><span class="msub">${esc(t.date)} · ${esc(t.description)}</span><span class="mtitle">${fmtMoney(t.amount)}</span></li>`).join('') : emptyRowHTML('No expenditure transactions yet.'));

    document.getElementById('repProfit').innerHTML = [
      ['Total Income', fmtMoney(totalIncome)],['Total Expenditure', fmtMoney(totalExp)],['Net Profit', fmtMoney(totalIncome-totalExp)]
    ].map(r=>`<li><span class="msub">${r[0]}</span><span class="mtitle">${r[1]}</span></li>`).join('');
  }

  /* ---------------- Settings ---------------- */
  function renderSettings(){
    document.getElementById('setShopName').value = state.settings.shopName;
    document.getElementById('setCurrency').value = state.settings.currency;
    document.getElementById('setMinStock').value = state.settings.minStockAlert;
    document.getElementById('setContact').value = state.settings.contact;
    document.getElementById('shopNameTag').textContent = state.settings.shopName.toUpperCase();
    document.getElementById('topShopChip').textContent = state.settings.currency + ' ' + (state.settings.currency==='₹' ? 'INR':'');
  }
  document.getElementById('saveSettingsBtn').addEventListener('click', ()=>{
    state.settings.shopName = document.getElementById('setShopName').value.trim() || 'My Shop';
    state.settings.currency = document.getElementById('setCurrency').value.trim() || '₹';
    state.settings.minStockAlert = parseInt(document.getElementById('setMinStock').value,10) || 0;
    state.settings.contact = document.getElementById('setContact').value.trim();
    persistAll();
    toast('Settings saved!', 'ok');
    renderAll();
  });

  /* ---------------- Confirm dialog ---------------- */
  let confirmCallback = null;
  function showConfirm(msg, cb){
    document.getElementById('confirmBody').textContent = msg;
    confirmCallback = cb;
    openModal('confirmOverlay');
  }
  document.getElementById('confirmActionBtn').addEventListener('click', ()=>{
    if(confirmCallback) confirmCallback();
    closeModal('confirmOverlay');
  });

  // close modal when clicking overlay background
  document.querySelectorAll('.modal-overlay').forEach(ov=>{
    ov.addEventListener('click', e=>{ if(e.target===ov) ov.classList.remove('show'); });
  });

  /* ---------------- Render all ---------------- */
  function renderAll(){
    renderDashboard();
    renderProducts();
    renderStock();
    renderIncome();
    renderExp();
    renderTransactions();
    renderReports();
    renderSettings();
  }

  renderAll();
  if(seeded){ /* sample data notice already visible via description fields */ }
})();
