package com.example.inventory.service;

import com.example.inventory.model.Product;
import com.example.inventory.repository.ProductRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ProductService {
    private final ProductRepository repository;

    public ProductService(ProductRepository repository) {
        this.repository = repository;
    }

    public List<Product> getAll() { return repository.findAll(); }

    public Product add(Product product) {
        if (repository.findByProductCode(product.getProductCode()).isPresent()) {
            throw new IllegalArgumentException("Product code already exists");
        }
        return repository.save(product);
    }

    public Product update(Long id, Product updated) {
        Product existing = repository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Product not found"));
        existing.setProductCode(updated.getProductCode());
        existing.setName(updated.getName());
        existing.setCategory(updated.getCategory());
        existing.setSupplier(updated.getSupplier());
        existing.setPurchasePrice(updated.getPurchasePrice());
        existing.setSellingPrice(updated.getSellingPrice());
        existing.setQuantity(updated.getQuantity());
        existing.setMinStock(updated.getMinStock());
        return repository.save(existing);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) throw new IllegalArgumentException("Product not found");
        repository.deleteById(id);
    }
}
