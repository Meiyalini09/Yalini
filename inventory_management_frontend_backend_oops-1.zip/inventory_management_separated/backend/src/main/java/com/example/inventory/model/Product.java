package com.example.inventory.model;

import jakarta.persistence.*;

@Entity
@Table(name = "products")
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, unique = true)
    private String productCode;
    @Column(nullable = false)
    private String name;
    private String category;
    private String supplier;
    private double purchasePrice;
    private double sellingPrice;
    private int quantity;
    private int minStock;

    protected Product() {}

    public Product(String productCode, String name, String category, String supplier,
                   double purchasePrice, double sellingPrice, int quantity, int minStock) {
        this.productCode = productCode;
        this.name = name;
        this.category = category;
        this.supplier = supplier;
        setPurchasePrice(purchasePrice);
        setSellingPrice(sellingPrice);
        setQuantity(quantity);
        setMinStock(minStock);
    }

    public Long getId() { return id; }
    public String getProductCode() { return productCode; }
    public void setProductCode(String productCode) { this.productCode = productCode; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public String getSupplier() { return supplier; }
    public void setSupplier(String supplier) { this.supplier = supplier; }
    public double getPurchasePrice() { return purchasePrice; }
    public void setPurchasePrice(double value) {
        if (value < 0) throw new IllegalArgumentException("Purchase price cannot be negative");
        this.purchasePrice = value;
    }
    public double getSellingPrice() { return sellingPrice; }
    public void setSellingPrice(double value) {
        if (value < 0) throw new IllegalArgumentException("Selling price cannot be negative");
        this.sellingPrice = value;
    }
    public int getQuantity() { return quantity; }
    public void setQuantity(int value) {
        if (value < 0) throw new IllegalArgumentException("Quantity cannot be negative");
        this.quantity = value;
    }
    public int getMinStock() { return minStock; }
    public void setMinStock(int value) {
        if (value < 0) throw new IllegalArgumentException("Minimum stock cannot be negative");
        this.minStock = value;
    }

    public String getStockStatus() {
        if (quantity == 0) return "Out of Stock";
        if (quantity <= minStock) return "Low Stock";
        return "Available";
    }
}
